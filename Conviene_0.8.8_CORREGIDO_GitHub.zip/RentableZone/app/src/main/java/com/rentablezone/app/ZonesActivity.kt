package com.rentablezone.app

import android.graphics.Color
import android.os.Bundle
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import org.osmdroid.config.Configuration
import org.osmdroid.events.MapEventsReceiver
import org.osmdroid.util.GeoPoint
import org.osmdroid.views.MapView
import org.osmdroid.tileprovider.tilesource.TileSourceFactory
import org.osmdroid.views.overlay.MapEventsOverlay
import org.osmdroid.views.overlay.Polygon

class ZonesActivity : AppCompatActivity() {
    private lateinit var map: MapView
    private val points = mutableListOf<GeoPoint>()
    private var poly: Polygon? = null
    private val savedZones = mutableListOf<SavedZone>()

    override fun onCreate(state: Bundle?) {
        super.onCreate(state)
        Configuration.getInstance().load(this, getSharedPreferences("osmdroid", MODE_PRIVATE))
        Configuration.getInstance().userAgentValue = "com.rentablezone.app/0.8.8"
        Configuration.getInstance().osmdroidBasePath = filesDir.resolve("osmdroid")
        Configuration.getInstance().osmdroidTileCache = filesDir.resolve("osmdroid/tiles")
        setContentView(R.layout.activity_zones)

        savedZones.addAll(ZoneStore.load(this))
        map = findViewById(R.id.map)
        // Configuración explícita para que las teselas de OpenStreetMap se muestren.
        map.setTileSource(TileSourceFactory.MAPNIK)
        map.setUseDataConnection(true)
        map.setMultiTouchControls(true)
        map.setBuiltInZoomControls(true)
        map.isTilesScaledToDpi = true
        map.setFlingEnabled(true)
        map.controller.setZoom(11.5)
        map.controller.setCenter(GeoPoint(-34.6037, -58.3816))
        map.invalidate()

        findViewById<Spinner>(R.id.spLocality).adapter =
            ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, Localities.all)
        findViewById<Spinner>(R.id.spZone).adapter =
            ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item,
                listOf("🟢 Permitida", "🟡 Precaución", "🔴 Peligrosa"))

        val receiver = object : MapEventsReceiver {
            override fun singleTapConfirmedHelper(p: GeoPoint): Boolean {
                points.add(p)
                redrawCurrent()
                return true
            }
            override fun longPressHelper(p: GeoPoint): Boolean = false
        }
        map.overlays.add(MapEventsOverlay(receiver))
        drawSaved()

        findViewById<Button>(R.id.btnSave).setOnClickListener {
            if (points.size < 3) {
                toast("Agrega al menos 3 puntos")
                return@setOnClickListener
            }
            val type = findViewById<Spinner>(R.id.spZone).selectedItemPosition
            val locality = findViewById<Spinner>(R.id.spLocality).selectedItem?.toString() ?: "Sin localidad"
            savedZones.add(SavedZone(type, locality, points.map { GeoPoint(it.latitude, it.longitude) }))
            ZoneStore.save(this, savedZones)
            toast("Zona $locality guardada")
            points.clear()
            poly?.let { map.overlays.remove(it) }
            poly = null
            map.invalidate()
        }

        findViewById<Button>(R.id.btnClear).setOnClickListener {
            points.clear()
            poly?.let { map.overlays.remove(it) }
            poly = null
            map.invalidate()
        }
    }

    private fun drawSaved() {
        savedZones.forEach { z ->
            if (z.points.size >= 3) {
                val c = color(z.type)
                val polygon = Polygon().apply {
                    points = z.points.map { GeoPoint(it.latitude, it.longitude) }
                    outlinePaint.color = c
                    outlinePaint.strokeWidth = 4f
                    fillPaint.color = Color.argb(50, Color.red(c), Color.green(c), Color.blue(c))
                    title = z.locality
                }
                map.overlays.add(polygon)
            }
        }
        map.invalidate()
    }

    private fun redrawCurrent() {
        poly?.let { map.overlays.remove(it) }
        if (points.size >= 3) {
            val c = color(findViewById<Spinner>(R.id.spZone).selectedItemPosition)
            poly = Polygon().apply {
                points = this@ZonesActivity.points.toList()
                outlinePaint.color = c
                outlinePaint.strokeWidth = 5f
                fillPaint.color = Color.argb(55, Color.red(c), Color.green(c), Color.blue(c))
            }
            map.overlays.add(poly)
        }
        map.invalidate()
    }

    private fun color(t: Int) = when (t) {
        0 -> Color.rgb(30, 170, 90)
        1 -> Color.rgb(220, 160, 20)
        else -> Color.rgb(210, 55, 70)
    }

    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_SHORT).show()

    override fun onResume() {
        super.onResume()
        map.onResume()
    }

    override fun onPause() {
        map.onPause()
        super.onPause()
    }

    override fun onDestroy() {
        map.onDetach()
        super.onDestroy()
    }
}
