# Conviene 0.8.8

Correcciones de estabilidad.

- Mapa de zonas usa osmdroid + OpenStreetMap, sin Google Maps API key.
- Caché de teselas configurada dentro del almacenamiento privado de la app.
- Se evita registrar dos veces el visor flotante.
- Se limpia correctamente MediaProjection/ImageReader al detener o reiniciar.
- El overlay queda visible desde el inicio de la sesión de captura y es arrastrable.
- No se envían toques a Uber/Cabify.
