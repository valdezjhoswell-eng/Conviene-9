package com.rentablezone.app

import android.app.*
import android.content.*
import android.graphics.*
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.*
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.content.pm.ServiceInfo
import android.os.*
import android.location.Geocoder
import java.util.concurrent.Executors
import android.provider.Settings
import android.view.*
import androidx.core.app.NotificationCompat
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.TextRecognizer
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import java.util.Locale
import kotlin.math.roundToInt

class ScreenCaptureService : Service() {
    private var projection: MediaProjection? = null
    private var reader: ImageReader? = null
    private var vd: VirtualDisplay? = null
    private var overlay: OverlayView? = null
    private var wm: WindowManager? = null
    private var overlayLp: WindowManager.LayoutParams? = null
    private val handler = Handler(Looper.getMainLooper())
    private val recognizer: TextRecognizer =
        TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS)
    private var busy = false
    private var lastOcrAt = 0L
    private var lastOfferFingerprint = ""
    private var lastOfferAt = 0L
    private val geoExec = Executors.newSingleThreadExecutor()
    private val prefs by lazy { getSharedPreferences("settings", 0) }

    override fun onCreate() {
        super.onCreate()
        createChannel()
    }

    override fun onStartCommand(i: Intent?, flags: Int, id: Int): Int {
        if (i == null) return START_NOT_STICKY
        val rc = i.getIntExtra("resultCode", 0)
        val data = i.getParcelableExtra<Intent>("data") ?: return START_NOT_STICKY

        startForeground(
            77, notification(),
            ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION
        )

        projection = getSystemService(MediaProjectionManager::class.java)
            .getMediaProjection(rc, data)

        showOverlay()
        startCapture()
        return START_NOT_STICKY
    }

    private fun notification(): Notification =
        NotificationCompat.Builder(this, "visor")
            .setSmallIcon(android.R.drawable.ic_menu_view)
            .setContentTitle("¿Conviene? activo")
            .setContentText("Observa la pantalla; no interactúa con Uber/Cabify")
            .setOngoing(true).build()

    private fun createChannel() {
        getSystemService(NotificationManager::class.java)
            .createNotificationChannel(
                NotificationChannel("visor", "¿Conviene?", NotificationManager.IMPORTANCE_LOW)
            )
    }

    private fun showOverlay() {
        if (!Settings.canDrawOverlays(this)) return
        wm = getSystemService(WindowManager::class.java)

        overlay = OverlayView(this) { dx, dy ->
            overlayLp?.let {
                it.x += dx
                it.y += dy
                try { wm?.updateViewLayout(overlay, it) } catch (_: Exception) {}
            }
        }

        val prefsWidth = prefs.getInt("sizeDp", 315).coerceIn(240, 420)
        overlay?.alpha = (prefs.getInt("alpha", 60).coerceIn(10, 100) / 100f)

        val lp = WindowManager.LayoutParams(
            dp(prefsWidth),
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        )
        lp.gravity = Gravity.TOP or Gravity.END
        lp.x = 12
        lp.y = 90
        overlayLp = lp
        wm?.addView(overlay, lp)
        overlay?.setVisible(false)
    }

    private fun startCapture() {
        val dm = resources.displayMetrics
        val w = dm.widthPixels
        val h = dm.heightPixels

        reader = ImageReader.newInstance(w, h, PixelFormat.RGBA_8888, 2)
        vd = projection?.createVirtualDisplay(
            "¿Conviene?", w, h, dm.densityDpi,
            DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,
            reader?.surface, null, null
        )
        reader?.setOnImageAvailableListener({ r ->
            if (!busy) process(r)
        }, handler)
    }

    private fun process(r: ImageReader) {
        val now = System.currentTimeMillis()
        if (busy || now - lastOcrAt < 500L) {
            try { r.acquireLatestImage()?.close() } catch (_: Exception) {}
            return
        }

        val im = try { r.acquireLatestImage() } catch (_: Exception) { null } ?: return
        busy = true
        lastOcrAt = now

        val plane = im.planes[0]
        val pixelStride = plane.pixelStride
        val rowStride = plane.rowStride
        val rowPadding = rowStride - pixelStride * im.width
        val paddedWidth = im.width + rowPadding / pixelStride

        val tmp = Bitmap.createBitmap(paddedWidth, im.height, Bitmap.Config.ARGB_8888)
        try {
            tmp.copyPixelsFromBuffer(plane.buffer)
        } catch (_: Exception) {
            im.close()
            tmp.recycle()
            busy = false
            return
        }
        im.close()

        val bmp = if (paddedWidth == im.width) tmp
        else Bitmap.createBitmap(tmp, 0, 0, im.width, im.height).also { tmp.recycle() }

        // Evita que el propio visor sea leído como parte de la oferta.
        maskOverlay(bmp)

        recognizer.process(InputImage.fromBitmap(bmp, 0))
            .addOnSuccessListener { result ->
                val offer = OfferParser.parseOffer(result, prefs)

                if (offer == null) {
                    // No hay una oferta emergente verificable: no mostrar ni reutilizar
                    // el cálculo anterior.
                    if (now - lastOfferAt > 1200L) overlay?.setVisible(false)
                    return@addOnSuccessListener
                }

                val fingerprint = offer.fingerprint
                if (fingerprint != lastOfferFingerprint) {
                    lastOfferFingerprint = fingerprint
                    lastOfferAt = now
                } else {
                    lastOfferAt = now
                }

                overlay?.showResult(offer.analysis)
                overlay?.setVisible(true)

                val dest = offer.analysis.destination
                if (dest.isNotBlank()) {
                    geoExec.execute {
                        val address = try {
                            Geocoder(this, Locale("es", "AR"))
                                .getFromLocationName(dest, 1)?.firstOrNull()
                        } catch (_: Exception) { null }

                        if (address != null) {
                            val type = ZoneStore.zoneFor(this, address.latitude, address.longitude)
                            val locality = ZoneStore.localityFor(this, address.latitude, address.longitude)
                            handler.post {
                                // Solo actualiza el mismo análisis; nunca toca la app de transporte.
                                overlay?.showResult(offer.analysis.withZone(type, locality))
                            }
                        }
                    }
                }
            }
            .addOnFailureListener {
                if (now - lastOfferAt > 1200L) overlay?.setVisible(false)
            }
            .addOnCompleteListener {
                busy = false
                bmp.recycle()
            }
    }

    /**
     * Cubre solamente el rectángulo actual del visor antes del OCR.
     * Así el propio texto del overlay nunca puede generar una nueva oferta.
     */
    private fun maskOverlay(bmp: Bitmap) {
        val v = overlay ?: return
        val loc = IntArray(2)
        try {
            v.getLocationOnScreen(loc)
            val left = loc[0].coerceIn(0, bmp.width)
            val top = loc[1].coerceIn(0, bmp.height)
            val right = (left + v.width).coerceIn(0, bmp.width)
            val bottom = (top + v.height).coerceIn(0, bmp.height)
            if (right > left && bottom > top) {
                Canvas(bmp).drawRect(left.toFloat(), top.toFloat(),
                    right.toFloat(), bottom.toFloat(),
                    Paint().apply { color = Color.BLACK })
            }
        } catch (_: Exception) {}
    }

    override fun onDestroy() {
        handler.removeCallbacksAndMessages(null)
        vd?.release()
        reader?.close()
        projection?.stop()
        overlay?.let { try { wm?.removeView(it) } catch (_: Exception) {} }
        recognizer.close()
        geoExec.shutdownNow()
        super.onDestroy()
    }

    override fun onBind(intent: Intent?) = null

    private fun dp(v: Int) =
        (v * resources.displayMetrics.density).roundToInt()
}

private data class ParsedOffer(
    val analysis: Analysis,
    val fingerprint: String
)

object OfferParser {
    private val money = Regex(
        """(?:ARS|\$)\s*([0-9][0-9.,]*)|([0-9][0-9.,]*)\s*ARS""",
        RegexOption.IGNORE_CASE
    )
    private val distance = Regex(
        """([0-9]+(?:[.,][0-9]+)?)\s*(km|m)\b""",
        RegexOption.IGNORE_CASE
    )
    private val minutes = Regex(
        """([0-9]+(?:[.,][0-9]+)?)\s*(min|mins|m)\b""",
        RegexOption.IGNORE_CASE
    )
    private val trips = Regex(
        """([0-9]+)\s*(viajes|trips)\b""",
        RegexOption.IGNORE_CASE
    )

    /**
     * CRITERIO CLAVE:
     * no analiza OCR genérico. Primero exige una firma de oferta:
     * importe + distancia + tiempo + señales de Uber/Cabify.
     * De esta manera el texto de la pantalla general no se interpreta como viaje.
     */
    fun parseOffer(
        result: com.google.mlkit.vision.text.Text,
        p: android.content.SharedPreferences
    ): ParsedOffer? {
        val blocks = result.textBlocks.flatMap { block ->
            block.lines.mapNotNull { line ->
                val box = line.boundingBox ?: return@mapNotNull null
                OcrLine(line.text.trim(), box.centerX().toFloat(), box.centerY().toFloat())
            }
        }.filter { it.text.isNotBlank() }

        if (blocks.isEmpty()) return null

        // No se analiza toda la pantalla como si fuera una oferta. Primero se
        // localiza una región compacta que contenga importe + distancia + tiempo.
        // Esto reduce falsos positivos provenientes del resto de Uber/Cabify.
        val moneyLines = blocks.filter { money.containsMatchIn(it.text) }
        val distanceLines = blocks.filter { distance.containsMatchIn(it.text) }
        val minuteLines = blocks.filter { minutes.containsMatchIn(it.text) }
        if (moneyLines.isEmpty() || distanceLines.isEmpty() || minuteLines.isEmpty()) return null

        val anchors = (moneyLines + distanceLines + minuteLines).distinct()
        val minX = anchors.minOf { it.x }
        val maxX = anchors.maxOf { it.x }
        val minY = anchors.minOf { it.y }
        val maxY = anchors.maxOf { it.y }

        // Margen suficiente para origen/destino y etiquetas del mismo cuadro.
        val marginX = 320f
        val marginY = 260f
        val candidate = blocks.filter {
            it.x in (minX - marginX)..(maxX + marginX) &&
            it.y in (minY - marginY)..(maxY + marginY)
        }.sortedBy { it.y }

        val full = candidate.joinToString(" ") { it.text }
        val low = full.lowercase(Locale.getDefault())

        val app = when {
            low.contains("cabify") -> "CABIFY"
            low.contains("uber") -> "UBER"
            // Si el nombre de la app no está dentro del popup, la firma de
            // oferta sigue siendo obligatoria. No se procesa texto suelto.
            else -> if (money.containsMatchIn(full) &&
                distance.findAll(full).count() >= 1 &&
                minutes.findAll(full).count() >= 1) "OFERTA" else null
        } ?: return null

        val amountValues = money.findAll(full)
            .mapNotNull { m ->
                parseNum(m.groupValues.firstOrNull { it.isNotBlank() })
            }.filter { it > 0 }.toList()

        // No hay umbral de importe: cualquier importe monetario visible de la
        // oferta debe entrar al cálculo. Los filtros deciden el resultado, no
        // si se calcula o no.
        val fare = amountValues.maxOrNull() ?: return null

        val distanceValues = distance.findAll(full).map {
            val n = parseNum(it.groupValues[1])
            if (it.groupValues[2].equals("m", true)) n / 1000.0 else n
        }.filter { it > 0 }.toList()

        val minuteValues = minutes.findAll(full).map {
            parseNum(it.groupValues[1])
        }.filter { it > 0 }.toList()

        // Una oferta real debe aportar distancia y tiempo. No usamos números
        // sueltos de la pantalla para completar datos faltantes.
        if (distanceValues.isEmpty() || minuteValues.isEmpty()) return null

        val hasOfferWords =
            low.contains("recog") || low.contains("pickup") ||
            low.contains("viaje") || low.contains("destino") ||
            low.contains("origen") || low.contains("hacia") ||
            low.contains("en app") || low.contains("efectivo") ||
            low.contains("cash") || low.contains("peajes") ||
            low.contains("passenger") || low.contains("pasajero")

        // Para reducir falsos positivos de pantallas normales:
        // app + importe + distancia + tiempo + una señal semántica.
        if (!hasOfferWords) return null

        // En las ofertas previstas, los dos primeros valores de cada magnitud
        // corresponden a recogida y viaje. No se suman valores arbitrarios de
        // otras partes de la pantalla.
        val totalDistance = when {
            distanceValues.size >= 2 -> distanceValues[0] + distanceValues[1]
            else -> {
                // Si la interfaz muestra una única distancia TOTAL del servicio,
                // la usamos como total visible. Nunca inventamos un regreso.
                distanceValues[0]
            }
        }

        val totalMinutes = when {
            minuteValues.size >= 2 -> minuteValues[0] + minuteValues[1]
            else -> minuteValues[0]
        }

        if (totalDistance <= 0 || totalMinutes <= 0) return null

        val perKm = fare / totalDistance
        val perHour = fare / (totalMinutes / 60.0)

        val maxKm = p.getFloat("maxKm", 30f).toDouble()
        val maxMin = p.getFloat("maxMin", 60f).toDouble()
        val minKm = p.getFloat("minKm", 500f).toDouble()
        val minHour = p.getFloat("minHour", 12000f).toDouble()
        val minTrips = p.getInt("minTrips", 0)

        val tripCount = trips.find(full)?.groupValues?.get(1)?.toIntOrNull()
        val cash = app == "CABIFY" &&
            (low.contains("efectivo") || low.contains("cash"))
        val inApp = app == "CABIFY" &&
            (low.contains("en app") || low.contains("app"))
        val tolls = app == "CABIFY" && low.contains("peaje")

        val cashMode = p.getInt("cashMode", 0)
        val appPayMode = p.getInt("appPayMode", 0)

        val failEconomic =
            perKm < minKm || perHour < minHour ||
            totalDistance > maxKm || totalMinutes > maxMin ||
            (tripCount != null && tripCount < minTrips)

        // "Marcar NO CONVIENE" solo cambia el resultado visual. Nunca se
        // pulsa/rechaza nada dentro de Cabify.
        val failPayment = (cash && cashMode == 2) || (inApp && appPayMode == 2)
        val evaluatePayment = (cash && cashMode == 1) || (inApp && appPayMode == 1)

        val label: String
        val color: Int
        when {
            failEconomic || failPayment -> {
                label = "🔴 NO CONVIENE"
                color = Color.rgb(200, 45, 45)
            }
            evaluatePayment -> {
                label = "🟡 EVALUAR"
                color = Color.rgb(205, 145, 0)
            }
            else -> {
                label = "🟢 CONVIENE"
                color = Color.rgb(30, 150, 70)
            }
        }

        val destination = extractDestination(blocks)
        val payment = when {
            cash -> "💵 EFECTIVO"
            inApp -> "💳 EN APP"
            else -> ""
        }

        val detail = buildString {
            append("💰 ${fmt(fare)} ARS bruto\n")
            append("📏 ${fmt1(totalDistance)} km\n")
            append("💵 ${fmt(perKm)}/km real\n")
            append("⏱️ ${fmt(perHour)}/h brutos\n")
            append("⌛ ${fmt1(totalMinutes)} min\n")
            if (tripCount != null) append("👤 $tripCount viajes\n")
            if (payment.isNotBlank()) append("$payment\n")
            if (tolls) append("🛣️ Peajes visibles\n")
            append(app)
        }

        val fp = "$app|${fmt(fare)}|${fmt1(totalDistance)}|${fmt1(totalMinutes)}|$destination"
        return ParsedOffer(Analysis(label, detail, color, destination), fp)
    }

    private data class OcrLine(val text: String, val x: Float, val y: Float)

    private fun extractDestination(lines: List<OcrLine>): String {
        val ordered = lines.sortedBy { it.y }
        for (i in ordered.indices) {
            val low = ordered[i].text.lowercase(Locale.getDefault())
            if (low.contains("destino") || low.contains("hacia") ||
                low.contains("viaje de")) {
                return ordered.getOrNull(i + 1)?.text?.take(100).orEmpty()
            }
        }
        return ""
    }

    private fun parseNum(s: String?): Double {
        if (s == null) return 0.0
        val x = s.trim()
        return when {
            x.contains('.') && x.contains(',') ->
                x.replace(".", "").replace(',', '.').toDoubleOrNull() ?: 0.0
            x.contains('.') && x.substringAfter('.').length == 3 ->
                x.replace(".", "").toDoubleOrNull() ?: 0.0
            x.contains(',') && x.substringAfter(',').length == 3 ->
                x.replace(",", "").toDoubleOrNull() ?: 0.0
            else -> x.replace(",", ".").toDoubleOrNull() ?: 0.0
        }
    }

    private fun fmt(v: Double) =
        String.format(Locale.US, "%,.0f", v).replace(',', '.')

    private fun fmt1(v: Double) =
        String.format(Locale.US, "%.1f", v).replace('.', ',')
}
