package com.rentablezone.app

import android.content.Context
import com.google.android.gms.maps.model.LatLng
import org.json.JSONArray
import org.json.JSONObject

data class SavedZone(
    val type: Int,                 // 0 verde, 1 amarilla, 2 roja
    val locality: String,
    val points: List<LatLng>
)

object Localities {
    // Selección manual por localidad. La lista es ampliable sin cambiar la lógica del mapa.
    val all = listOf(
        "CABA",
        "Hurlingham", "Villa Tesei", "William C. Morris",
        "Morón", "Castelar", "Haedo", "El Palomar",
        "Ituzaingó", "Villa Udaondo",
        "Tres de Febrero", "Caseros", "Ciudadela", "Sáenz Peña", "Villa Bosch",
        "San Martín", "Villa Ballester", "San Andrés", "José León Suárez",
        "La Matanza", "Ramos Mejía", "San Justo", "Lomas del Mirador",
        "Villa Luzuriaga", "Isidro Casanova", "Ciudad Evita", "González Catán",
        "Rafael Castillo", "Gregorio de Laferrere", "Virrey del Pino",
        "Merlo", "San Antonio de Padua", "Libertad", "Mariano Acosta",
        "Moreno", "Paso del Rey", "Trujui",
        "Ituzaingó", "José C. Paz", "San Miguel", "Muñiz", "Bella Vista",
        "Malvinas Argentinas", "Los Polvorines", "Grand Bourg", "Adolfo Sourdeaux",
        "Tigre", "General Pacheco", "Don Torcuato", "El Talar", "Benavídez",
        "San Fernando", "Victoria", "Virreyes",
        "San Isidro", "Martínez", "Acassuso", "Beccar", "Boulogne",
        "Vicente López", "Florida", "Munro", "Olivos", "Villa Martelli",
        "Quilmes", "Bernal", "Ezpeleta", "Don Bosco",
        "Avellaneda", "Sarandí", "Wilde", "Dock Sud", "Gerli",
        "Lanús", "Remedios de Escalada", "Valentín Alsina", "Monte Chingolo",
        "Lomas de Zamora", "Banfield", "Temperley", "Adrogué", "Turdera",
        "Almirante Brown", "Burzaco", "Claypole", "Longchamps", "Glew",
        "Esteban Echeverría", "Monte Grande", "Luis Guillón", "El Jagüel",
        "Ezeiza", "Tristán Suárez", "Canning",
        "Berazategui", "Florencio Varela", "San Vicente", "Presidente Perón"
    ).distinct().sorted()
}

object ZoneStore {
    private const val KEY = "saved_zones"

    fun load(c: Context): List<SavedZone> {
        val raw = c.getSharedPreferences("zones", 0).getString(KEY, "[]") ?: "[]"
        val a = JSONArray(raw)
        return buildList {
            for (i in 0 until a.length()) {
                val o = a.getJSONObject(i)
                val pts = o.getJSONArray("p")
                val locality = o.optString("l", "Sin localidad")
                add(SavedZone(
                    o.optInt("t", 1),
                    locality,
                    buildList {
                        for (j in 0 until pts.length()) {
                            val q = pts.getJSONObject(j)
                            add(LatLng(q.getDouble("lat"), q.getDouble("lng")))
                        }
                    }
                ))
            }
        }
    }

    fun save(c: Context, zones: List<SavedZone>) {
        val a = JSONArray()
        zones.forEach { zone ->
            val p = JSONArray()
            zone.points.forEach { p.put(JSONObject()
                .put("lat", it.latitude)
                .put("lng", it.longitude)) }
            a.put(JSONObject()
                .put("t", zone.type)
                .put("l", zone.locality)
                .put("p", p))
        }
        c.getSharedPreferences("zones", 0).edit()
            .putString(KEY, a.toString()).apply()
    }

    /** Prioridad segura: roja > amarilla > verde si hay polígonos superpuestos. */
    fun zoneFor(c: Context, lat: Double, lng: Double): Int? =
        load(c)
            .filter { it.points.size >= 3 && contains(it.points, LatLng(lat, lng)) }
            .maxByOrNull { it.type }?.type

    fun localityFor(c: Context, lat: Double, lng: Double): String? =
        load(c)
            .filter { it.points.size >= 3 && contains(it.points, LatLng(lat, lng)) }
            .maxByOrNull { it.type }?.locality

    private fun contains(poly: List<LatLng>, p: LatLng): Boolean {
        var inside = false
        var j = poly.lastIndex
        for (i in poly.indices) {
            val xi = poly[i].longitude
            val yi = poly[i].latitude
            val xj = poly[j].longitude
            val yj = poly[j].latitude
            val cross = ((yi > p.latitude) != (yj > p.latitude)) &&
                (p.longitude < (xj - xi) * (p.latitude - yi) / (yj - yi + 1e-12) + xi)
            if (cross) inside = !inside
            j = i
        }
        return inside
    }
}
