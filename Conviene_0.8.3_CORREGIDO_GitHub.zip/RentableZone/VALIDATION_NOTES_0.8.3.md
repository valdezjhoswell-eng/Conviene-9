# Conviene 0.8.3 - correcciones de compilación

Correcciones aplicadas sobre 0.8.2:

- `OverlayView`: `TextView.setTextColor()` en lugar de la propiedad inexistente `textColor`.
- `ScreenCaptureService`: import explícito de `android.hardware.display.VirtualDisplay`.
- OCR: conversión explícita de `Rect.centerX()/centerY()` de `Int` a `Float`.
- Se mantiene el cálculo: distancia = recogida + viaje; tiempo = recogida + viaje; sin regreso.
- El cálculo solo se produce cuando el parser identifica una firma mínima de oferta en la captura OCR; no se reutiliza el último cálculo si la oferta desaparece.
- El overlay se enmascara antes del OCR para no leerse a sí mismo.

Nota: esta versión no puede garantizar la identificación visual exacta de todos los diseños futuros de Uber/Cabify sin muestras reales de pantalla. No interactúa con sus controles.
