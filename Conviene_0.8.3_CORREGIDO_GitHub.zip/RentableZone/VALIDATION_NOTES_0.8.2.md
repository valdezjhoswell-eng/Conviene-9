# Validación 0.8.2

## Regla de cálculo
- Distancia total = distancia hasta recogida + distancia del viaje.
- Tiempo total = tiempo hasta recogida + tiempo del viaje.
- No existe cálculo de retorno.

## Regla de activación
El OCR no debe producir un resultado solo porque encuentre números en la pantalla.
Debe existir una región candidata con:
- importe monetario;
- al menos una distancia;
- al menos un tiempo;
- señal semántica de oferta.

El overlay se enmascara antes del OCR.

## Filtros
Los filtros no bloquean el cálculo. Primero se calculan importe, distancia, tiempo, $/km y $/hora; después se decide el estado visual.

## Zonas
Cada polígono guardado tiene:
- localidad;
- tipo verde/amarillo/rojo.

En superposición, rojo tiene prioridad.
