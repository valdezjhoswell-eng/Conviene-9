package com.rentablezone.app

import android.content.Context
import com.google.android.gms.maps.model.LatLng
import org.json.JSONArray
import org.json.JSONObject

data class SavedZone(val type:Int,val points:List<LatLng>)
object ZoneStore{
    private const val KEY="saved_zones"
    fun load(c:Context):List<SavedZone>{val raw=c.getSharedPreferences("zones",0).getString(KEY,"[]")?:"[]";val a=JSONArray(raw);return buildList{for(i in 0 until a.length()){val o=a.getJSONObject(i);val pts=o.getJSONArray("p");add(SavedZone(o.getInt("t"),buildList{for(j in 0 until pts.length()){val q=pts.getJSONObject(j);add(LatLng(q.getDouble("lat"),q.getDouble("lng")))}}))}}
    fun save(c:Context,z:List<SavedZone>){val a=JSONArray();z.forEach{zone->val o=JSONObject().put("t",zone.type);val p=JSONArray();zone.points.forEach{p.put(JSONObject().put("lat",it.latitude).put("lng",it.longitude))};o.put("p",p);a.put(o)};c.getSharedPreferences("zones",0).edit().putString(KEY,a.toString()).apply()}
    fun zoneFor(c:Context,lat:Double,lng:Double):Int?{val p=LatLng(lat,lng);return load(c).asSequence().filter{it.points.size>=3 && contains(it.points,p)}.map{it.type}.firstOrNull()}
    private fun contains(poly:List<LatLng>,p:LatLng):Boolean{var inside=false;var j=poly.lastIndex;for(i in poly.indices){val xi=poly[i].longitude;val yi=poly[i].latitude;val xj=poly[j].longitude;val yj=poly[j].latitude;val cross=((yi>p.latitude)!=(yj>p.latitude)) && (p.longitude < (xj-xi)*(p.latitude-yi)/(yj-yi+1e-12)+xi);if(cross)inside=!inside;j=i};return inside}
}
