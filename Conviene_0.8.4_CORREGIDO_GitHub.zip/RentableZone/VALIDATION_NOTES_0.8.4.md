# Conviene 0.8.4

Corrección de compilación: `ParsedOffer` ya no es `private` porque es el tipo de retorno de la función pública `OfferParser.parseOffer`.

Se mantienen las reglas funcionales de 0.8.x: distancia = recogida + viaje; tiempo = recogida + viaje; sin regreso; análisis solamente de una región candidata de oferta; sin interacción con Uber/Cabify.
