# Conviene 0.8.7

Correcciones de compilación del editor de zonas:
- Se eliminó el import inexistente `MapEvents`.
- Se reemplazó `Polygon.remove()` por eliminación explícita desde `map.overlays`.
- Se configuró explícitamente `TileSourceFactory.MAPNIK`.
- Se habilitó el uso de datos para las teselas OSM.
- Se actualizó versionName a 0.8.7.

El warning de Gradle sobre `libmlkit_google_ocr_pipeline.so` no es la causa del fallo de Kotlin; la biblioteca se empaqueta sin stripping.
