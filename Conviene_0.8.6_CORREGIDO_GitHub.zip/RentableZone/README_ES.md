# Visor Rentable 0.1 — APK personal para Galaxy Tab A11

Esta versión es un proyecto Android para uso personal. La aplicación **no pulsa Aceptar/Rechazar ni controla Uber/Cabify**. Usa la captura de pantalla autorizada por Android para leer visualmente la oferta y coloca un panel flotante no táctil sobre la pantalla.

## Funciones incluidas
- Visor flotante no interactivo.
- Transparencia configurable.
- Captura MediaProjection.
- OCR de la pantalla con ML Kit.
- Detección básica de Uber/Cabify.
- Cálculo de $/km y $/hora.
- Filtros de km, minutos y rentabilidad.
- Filtro de cantidad de viajes (estructura preparada; depende de que el OCR encuentre el dato).
- Cabify: selector de tratamiento de efectivo.
- Mapa de zonas con colores verde/amarillo/rojo y dibujo de polígonos.

## Importante
El mapa usa OpenStreetMap mediante osmdroid. No requiere una clave de Google Maps. Necesita conexión a Internet para descargar las teselas del mapa.

## Compilar APK
Abrir la carpeta en Android Studio, sincronizar Gradle y ejecutar `Build > Build APK(s)`. El APK de debug aparecerá en `app/build/outputs/apk/debug/`.

## Permisos al instalar
1. Permitir "Mostrar sobre otras aplicaciones".
2. Iniciar el visor.
3. Aceptar el diálogo de Android para compartir/capturar pantalla.
4. Mantener la notificación del servicio activo mientras se trabaja.

## Criterio de distancia
La distancia para rentabilidad es **recogida + viaje con pasajero**. No se considera el regreso. Si la recogida aparece en metros (por ejemplo 828 m), se convierte a 0,828 km y se suma.

## Nota sobre OCR
Esta 0.1 es un prototipo: los formatos de Uber/Cabify pueden cambiar y el OCR puede confundirse con números o textos. Antes de usarlo en producción personal conviene probarlo con varias capturas reales y ajustar los patrones.


## Correcciones de la versión 0.8.2

- La aplicación **no interpreta toda la pantalla como una oferta**. El OCR busca primero una región compacta con importe + distancia + tiempo y exige señales semánticas de una oferta.
- El texto del propio overlay se tapa antes del OCR para evitar que el visor se lea a sí mismo.
- Si no se detecta una oferta válida, el visor queda inactivo y no conserva un cálculo anterior.
- El importe no tiene un mínimo artificial: se calcula cualquier importe monetario visible; los límites configurados solo determinan CONVIENE / NO CONVIENE / EVALUAR.
- La distancia de rentabilidad sigue siendo exclusivamente **recogida + viaje**. Nunca se agrega ni se estima regreso.
- El tiempo de rentabilidad sigue siendo exclusivamente **tiempo hasta recogida + tiempo de viaje**.
- Si solo aparece una distancia o un tiempo visible, se utiliza ese valor como total visible; no se inventa ningún regreso ni se agregan números ajenos al cuadro detectado.
- Las zonas se pueden guardar asociadas a una **localidad seleccionada**.
- Si existen polígonos superpuestos, la prioridad es **roja > amarilla > verde**.
- Se agregó configuración independiente para el tratamiento del pago Cabify en app.
- El visor permite arrastrarse y ajustar tamaño/transparencia. Arrastrarlo solo modifica su propia posición; no ejecuta acciones sobre Uber/Cabify.
- Los estados de pago que dicen “marcar NO CONVIENE” son únicamente un resultado visual: la aplicación jamás pulsa, acepta o rechaza viajes.

## 0.8.5

- El visor queda visible como pequeña pestaña `¿CONVIENE?` aun cuando está esperando una oferta.
- La pestaña puede arrastrarse.
- Cuando no hay oferta válida muestra `Esperando oferta…` y no reutiliza el análisis anterior.
- El mapa usa OpenStreetMap y no requiere `MAPS_API_KEY`.
- La navegación puede abrirse como acción independiente hacia el destino, sin controlar Uber/Cabify.
