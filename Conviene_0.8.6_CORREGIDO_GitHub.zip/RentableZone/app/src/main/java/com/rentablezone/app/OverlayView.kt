package com.rentablezone.app

import android.content.Context
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.view.MotionEvent
import android.widget.LinearLayout
import android.widget.TextView

/** Small draggable informational overlay. It never sends input to Uber/Cabify. */
class OverlayView(
    context: Context,
    private val onDrag: (dx: Int, dy: Int) -> Unit
) : LinearLayout(context) {
    private val title = TextView(context)
    private val detail = TextView(context)
    private var downX = 0f
    private var downY = 0f

    init {
        orientation = VERTICAL
        setPadding(14, 8, 14, 8)
        background = GradientDrawable().apply {
            setColor(Color.argb(220, 235, 235, 235))
            cornerRadius = 18f
        }
        title.text = "¿CONVIENE?"
        title.setTextColor(Color.DKGRAY)
        title.textSize = 16f
        title.setTypeface(null, 1)
        detail.setTextColor(Color.DKGRAY)
        detail.textSize = 13f
        addView(title)
        addView(detail)

        // Only the small Conviene window receives these touch events. It does not
        // dispatch, click or otherwise control the underlying transport app.
        setOnTouchListener { _, e ->
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    downX = e.rawX
                    downY = e.rawY
                    true
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = (e.rawX - downX).toInt()
                    val dy = (e.rawY - downY).toInt()
                    if (dx != 0 || dy != 0) {
                        onDrag(dx, dy)
                        downX = e.rawX
                        downY = e.rawY
                    }
                    true
                }
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> true
                else -> true
            }
        }
    }

    fun showResult(result: Analysis) {
        title.text = result.label
        title.setTextColor(result.color)
        detail.text = result.detail
    }

    fun setVisible(visible: Boolean) {
        visibility = if (visible) VISIBLE else INVISIBLE
    }

    fun showIdle() {
        title.text = "¿CONVIENE?"
        title.setTextColor(Color.DKGRAY)
        detail.text = "Esperando oferta…"
    }
}

data class Analysis(
    val label: String,
    val detail: String,
    val color: Int,
    val destination: String = ""
) {
    fun withZone(type: Int?, locality: String?): Analysis {
        val suffix = when (type) {
            2 -> "\n🔴 ZONA PELIGROSA"
            1 -> "\n🟡 ZONA DE PRECAUCIÓN"
            0 -> "\n🟢 ZONA PERMITIDA"
            else -> ""
        }
        val local = if (!locality.isNullOrBlank()) "\n📍 $locality" else ""
        return copy(
            detail = detail + suffix + local,
            label = if (type == 2) "🔴 NO CONVIENE" else label,
            color = if (type == 2) Color.rgb(200, 45, 45) else color
        )
    }
}
