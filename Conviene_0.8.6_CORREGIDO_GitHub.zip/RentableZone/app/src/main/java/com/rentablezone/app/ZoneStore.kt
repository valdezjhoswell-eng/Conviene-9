package com.rentablezone.app

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import org.osmdroid.util.GeoPoint

data class SavedZone(
    val type: Int,
    val locality: String,
    val points: List<GeoPoint>
)

object Localities {
    val all = listOf(
        "CABA",
        "Hurlingham", "Villa Tesei", "William C. Morris",
        "Morón", "Castelar", "Haedo", "El Palomar",
        "Ituzaingó", "Villa Udaondo",
        "Tres de Febrero", "Caseros", "Ciudadela", "Sáenz Peña", "Villa Bosch",
        "San Martín", "Villa Ballester", "San Andrés", "José León Suárez",
        "La Matanza", "Ramos Mejía", "San Justo", "Lomas del Mirador",
        "Villa Luzuriaga", "Isidro Casanova", "Ciudad Evita", "González Catán",
        "Rafael Castillo", "Gregorio de Laferrere", "Virrey del Pino",
        "Merlo", "San Antonio de Padua", "Libertad", "Mariano Acosta",
        "Moreno", "Paso del Rey", "Trujui",
        "José C. Paz", "San Miguel", "Muñiz", "Bella Vista",
        "Malvinas Argentinas", "Los Polvorines", "Grand Bourg", "Adolfo Sourdeaux",
        "Tigre", "General Pacheco", "Don Torcuato", "El Talar", "Benavídez",
        "San Fernando", "Victoria", "Virreyes",
        "San Isidro", "Martínez", "Acassuso", "Beccar", "Boulogne",
        "Vicente López", "Florida", "Munro", "Olivos", "Villa Martelli",
        "Quilmes", "Bernal", "Ezpeleta", "Don Bosco",
        "Avellaneda", "Sarandí", "Wilde", "Dock Sud", "Gerli",
        "Lanús", "Remedios de Escalada", "Valentín Alsina", "Monte Chingolo",
        "Lomas de Zamora", "Banfield", "Temperley", "Adrogué", "Turdera",
        "Almirante Brown", "Burzaco", "Claypole", "Longchamps", "Glew",
        "Esteban Echeverría", "Monte Grande", "Luis Guillón", "El Jagüel",
        "Ezeiza", "Tristán Suárez", "Canning",
        "Berazategui", "Florencio Varela", "San Vicente", "Presidente Perón"
    ).distinct().sorted()
}

object ZoneStore {
    private const val KEY = "saved_zones"

    fun load(c: Context): List<SavedZone> {
        val raw = c.getSharedPreferences("zones", 0).getString(KEY, "[]") ?: "[]"
        val a = JSONArray(raw)
        return buildList {
            for (i in 0 until a.length()) {
                val o = a.getJSONObject(i)
                val pts = o.getJSONArray("p")
                add(SavedZone(
                    o.optInt("t", 1),
                    o.optString("l", "Sin localidad"),
                    buildList {
                        for (j in 0 until pts.length()) {
                            val q = pts.getJSONObject(j)
                            add(GeoPoint(q.getDouble("lat"), q.getDouble("lng")))
                        }
                    }
                ))
            }
        }
    }

    fun save(c: Context, zones: List<SavedZone>) {
        val a = JSONArray()
        zones.forEach { zone ->
            val p = JSONArray()
            zone.points.forEach { point ->
                p.put(JSONObject().put("lat", point.latitude).put("lng", point.longitude))
            }
            a.put(JSONObject().put("t", zone.type).put("l", zone.locality).put("p", p))
        }
        c.getSharedPreferences("zones", 0).edit().putString(KEY, a.toString()).apply()
    }

    fun zoneFor(c: Context, lat: Double, lng: Double): Int? =
        load(c).filter { it.points.size >= 3 && contains(it.points, lat, lng) }
            .maxByOrNull { it.type }?.type

    fun localityFor(c: Context, lat: Double, lng: Double): String? =
        load(c).filter { it.points.size >= 3 && contains(it.points, lat, lng) }
            .maxByOrNull { it.type }?.locality

    private fun contains(poly: List<GeoPoint>, lat: Double, lng: Double): Boolean {
        var inside = false
        var j = poly.lastIndex
        for (i in poly.indices) {
            val xi = poly[i].longitude
            val yi = poly[i].latitude
            val xj = poly[j].longitude
            val yj = poly[j].latitude
            val crosses = ((yi > lat) != (yj > lat)) &&
                (lng < (xj - xi) * (lat - yi) / (yj - yi + 1e-12) + xi)
            if (crosses) inside = !inside
            j = i
        }
        return inside
    }
}
