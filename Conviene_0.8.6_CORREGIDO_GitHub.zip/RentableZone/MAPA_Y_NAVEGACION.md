# Mapa y navegación — Conviene 0.8.6

El editor de zonas usa OpenStreetMap mediante osmdroid, por lo que no depende de una API key de Google Maps.

## Uso
1. Selecciona una localidad.
2. Selecciona Permitida, Precaución o Peligrosa.
3. Toca el mapa para agregar puntos.
4. Con tres o más puntos se muestra el polígono.
5. Guarda la zona.

Las zonas se guardan asociadas a la localidad elegida y se mantienen en el dispositivo.

La navegación al destino, cuando se implemente/active, será independiente de Uber/Cabify y no pulsará sus controles.
